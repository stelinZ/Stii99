# Sony Pods — WF-1000XM5 connection card for Android

A lightweight Android app for Sony WF-1000XM5 with an interactive **3D model** and Apple AirPods–style connection animation, battery display, device selection, and a foreground Bluetooth monitoring service.

## ✨ 3D Mode (New)

The app includes a fully interactive 3D model of the Sony WF-1000XM5 earbuds and charging case, rendered via WebGL (Three.js):

- **Lid opening animation** — case lid swings open on its hinge
- **Earbud extraction** — earbuds spring out of the case with a physics-based bounce
- **Earbud return** — earbuds descend back into their compartments
- **360° rotation** — continuous showcase spin
- **Touch interaction** — drag to orbit, pinch to zoom
- **Color variants** — Black, Platinum Silver, Smoky Pink
- **Swipe to dismiss** — the popup card dismisses with a downward swipe

The 3D model features:
- Superellipsoid-based case geometry matching real dimensions (64.6 × 26.5 × 40 mm)
- Individual left/right earbuds with glossy touch surface, copper accent ring, sensor dot, stem, nozzle, and ear tips
- PBR materials with proper metallic/roughness values
- Studio lighting setup with key, fill, rim, and ambient lights
- Breathing LED indicator on the case
- Animated battery rings drawn natively for crispness

You can toggle between the 3D model and the classic 2D Canvas animation in Settings.

## Build APK

The repository includes a GitHub Actions workflow:

1. Create a GitHub repository and upload the contents of this project.
2. Open **Actions → Build Sony Pods APK → Run workflow** (or push to `main`/`master`).
3. Download `app-debug.apk` from the workflow run's **Artifacts**, or use the latest GitHub Release.
4. Install the APK on the phone and open Sony Pods.

## First-time setup

1. Grant **Nearby devices / Bluetooth** permission.
2. Grant **Display over other apps** permission for the floating connection card.
3. Select the paired WF-1000XM5 (or leave automatic selection enabled).
4. Use **Проверить 3D анимацию** to preview the card.

## Project structure

```
app/src/main/
├── assets/
│   ├── viewer.html                    — Three.js 3D scene
│   ├── js/                            — Three.js runtime (bundled offline)
│   │   ├── three.module.min.js
│   │   ├── GLTFLoader.js
│   │   ├── OrbitControls.js
│   │   └── BufferGeometryUtils.js
│   └── models/                        — GLB 3D models
│       ├── sony_wf1000xm5_complete.glb  (231 KB — full scene)
│       ├── earbud_left.glb
│       ├── earbud_right.glb
│       ├── case_body.glb
│       └── case_lid.glb
├── java/app/sonypods/
│   ├── MainActivity.kt                — Main UI with 3D preview + controls
│   ├── Pods3DCardView.kt              — 3D card (WebView + native HUD overlay)
│   ├── PodsCardView.kt                — Classic 2D Canvas card (fallback)
│   ├── PopupController.kt             — Overlay popup with smart gesture handling
│   ├── PodsService.kt                 — Foreground BT monitoring service
│   ├── SonyReader.kt                  — Experimental Sony RFCOMM battery reader
│   └── BootReceiver.kt                — Auto-start on boot
└── res/                               — Icons, colors, manifest
```

## Performance

- Total 3D assets: **~528 KB** (GLB models) + **~828 KB** (Three.js runtime)
- Target: **60 FPS** on Samsung Galaxy S25+
- WebView GPU acceleration enabled
- Shadow maps: 1024×1024
- Pixel ratio capped at 2× for efficiency
- No network requests (all assets bundled)

## Important compatibility note

The 3D model and animations are rendered locally via a WebView (Three.js / WebGL). No network access or external 3D engine is required. Battery data is a separate concern: Android's public Bluetooth APIs do not consistently expose independent left/right/case values. `SonyReader.kt` is explicitly experimental and its private Sony RFCOMM framing has not been validated against a physical WF-1000XM5 in this project. A missing value is shown as `—`; demo values are used only in the preview button. Close Sony Sound Connect during protocol testing because another client may hold the control connection.

This project does not claim to be an Apple product and does not use Apple's proprietary artwork or branding. The 3D model of the Sony WF-1000XM5 was created from scratch using official product dimensions and photographs as reference.
