package app.sonypods

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var btStatus: TextView
    private lateinit var overlayStatus: TextView
    private val prefs by lazy { getSharedPreferences("sonypods", MODE_PRIVATE) }
    private val white = Color.WHITE
    private val muted = Color.rgb(165, 172, 188)
    private val bg = Color.rgb(10, 12, 17)
    private val accent = Color.rgb(126, 166, 255)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private var preview3D: Pods3DCardView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg; window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(26), dp(20), dp(28))
            setBackgroundColor(bg)
        }
        root.addView(label("SONY  /  PODS", 12f, accent, true))
        root.addView(label("Твои наушники.\nНовый уровень.", 31f, white, true).apply {
            setPadding(0, dp(10), 0, dp(5)); letterSpacing = -.02f
        })
        root.addView(label("3D анимация подключения в стиле AirPods для WF-1000XM5", 14f, muted).apply {
            setPadding(0, 0, 0, dp(20))
        })

        // ── 3D Preview Card ──
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(15), dp(15), dp(16))
            background = rounded(Color.rgb(26, 30, 40), 28, Color.rgb(55, 63, 81))
        }
        hero.addView(label("3D ПРЕДПРОСМОТР", 10f, muted, true))

        val preview = Pods3DCardView(this).apply {
            title = "WF-1000XM5"
            setState(PodsState(87, 85, 100, caseChg = true))
        }
        preview3D = preview
        hero.addView(preview, LinearLayout.LayoutParams(-1, dp(320)).apply { topMargin = dp(8) })
        root.addView(hero)

        // ── 3D Controls ──
        root.addView(label("3D УПРАВЛЕНИЕ", 11f, muted, true).apply { setPadding(dp(2), dp(18), 0, dp(9)) })

        val controlsRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        addSmallAction(controlsRow1, "Открыть") { preview3D?.triggerOpen() }
        addSmallAction(controlsRow1, "Закрыть") { preview3D?.triggerClose() }
        addSmallAction(controlsRow1, "Достать") { preview3D?.triggerExtract() }
        addSmallAction(controlsRow1, "Вернуть") { preview3D?.triggerReturn() }
        addSmallAction(controlsRow1, "360°") { preview3D?.trigger360() }
        root.addView(controlsRow1)

        val controlsRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        addSmallAction(controlsRow2, "Чёрный") { preview3D?.setColorVariant("black") }
        addSmallAction(controlsRow2, "Серебро") { preview3D?.setColorVariant("silver") }
        addSmallAction(controlsRow2, "Розовый") { preview3D?.setColorVariant("pink") }
        addSmallAction(controlsRow2, "Сброс") { preview3D?.resetCamera() }
        root.addView(controlsRow2)

        // ── System Status ──
        root.addView(label("СОСТОЯНИЕ СИСТЕМЫ", 11f, muted, true).apply { setPadding(dp(2), dp(22), 0, dp(9)) })
        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(Color.rgb(24, 27, 35), 20)
        }
        status = label("Проверяем разрешения…", 14f, white)
        btStatus = label("Bluetooth: проверка", 13f, muted)
        overlayStatus = label("Поверх окон: проверка", 13f, muted)
        statusCard.addView(status); statusCard.addView(btStatus.apply { setPadding(0, dp(9), 0, 0) })
        statusCard.addView(overlayStatus.apply { setPadding(0, dp(5), 0, 0) })
        root.addView(statusCard)

        // ── Settings ──
        root.addView(label("НАСТРОЙКА", 11f, muted, true).apply { setPadding(dp(2), dp(22), 0, dp(9)) })
        addAction(root, "Разрешения Bluetooth и уведомлений", "Доступ к устройству и фоновому уведомлению") { requestBluetooth() }
        addAction(root, "Разрешить всплывающую карточку", "Показ поверх других приложений") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addAction(root, "Выбрать устройство", "Автоматический поиск или конкретные наушники") { pick() }
        addAction(root, "Проверить 3D анимацию", "Показать 3D карточку подключения") {
            PopupController(this).show("WF-1000XM5", PodsState(87, 85, 100, caseChg = true))
        }

        // ── 3D/2D toggle ──
        val use3D = prefs.getBoolean("use3d", true)
        addAction(root, if (use3D) "Режим: 3D (активен)" else "Режим: 2D (классический)",
            "Переключить между 3D моделью и 2D анимацией") {
            val current = prefs.getBoolean("use3d", true)
            prefs.edit().putBoolean("use3d", !current).apply()
            Toast.makeText(this, if (!current) "3D режим включён" else "2D режим включён", Toast.LENGTH_SHORT).show()
            recreate()
        }

        root.addView(label("Заметка: отдельный заряд левого и правого наушника и кейса зависит от ответа фирменного протокола Sony. Если данные недоступны, приложение покажет доступный общий заряд или прочерк — тестовые значения не выдаются за реальные.", 12f, muted).apply {
            setPadding(dp(3), dp(16), dp(3), 0)
        })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    private fun addSmallAction(parent: LinearLayout, title: String, action: () -> Unit) {
        val btn = TextView(this).apply {
            text = title
            textSize = 12f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(24, 27, 35), 16, Color.rgb(45, 50, 62))
            isClickable = true; isFocusable = true
            gravity = Gravity.CENTER
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(3); lp.marginEnd = dp(3)
        parent.addView(btn, lp)
    }

    private fun addAction(parent: LinearLayout, title: String, subtitle: String, action: () -> Unit) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(13), dp(16), dp(13))
            background = rounded(Color.rgb(24, 27, 35), 18)
            isClickable = true; isFocusable = true
            setOnClickListener { action() }
        }
        item.addView(label(title, 15f, white, true))
        item.addView(label(subtitle, 12f, muted).apply { setPadding(0, dp(4), 0, 0) })
        parent.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun requestBluetooth() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            permissions += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permissions += Manifest.permission.POST_NOTIFICATIONS
        if (permissions.isNotEmpty()) requestPermissions(permissions.toTypedArray(), 1)
        else Toast.makeText(this, "Разрешения уже выданы", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        val bt = !btMissing(); val ov = Settings.canDrawOverlays(this)
        btStatus.text = (if (bt) "●" else "○") + "  Bluetooth и доступ к устройству"
        overlayStatus.text = (if (ov) "●" else "○") + "  Показ поверх других окон"
        status.text = if (bt && ov) "Готово к подключению" else "Нужно завершить настройку"
        if (bt && ov) {
            try { startForegroundService(Intent(this, PodsService::class.java)) }
            catch (_: Exception) { Toast.makeText(this, "Не удалось запустить фоновый сервис. Открой приложение ещё раз.", Toast.LENGTH_LONG).show() }
        }
    }

    private fun btMissing() = Build.VERSION.SDK_INT >= 31 &&
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun pick() {
        if (btMissing()) { requestBluetooth(); return }
        val bonded = try { (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter.bondedDevices.toList() }
            catch (_: Exception) { emptyList() }
        val names = (listOf("Авто (WF-1000XM5)") + bonded.map { (it.name ?: "Bluetooth") + "  ·  " + it.address.takeLast(5) }).toTypedArray()
        AlertDialog.Builder(this).setTitle("Выбрать наушники").setItems(names) { _, i ->
            val e = prefs.edit()
            if (i == 0) e.remove("addr") else e.putString("addr", bonded[i - 1].address)
            e.apply(); Toast.makeText(this, "Устройство сохранено", Toast.LENGTH_SHORT).show(); onResume()
        }.show()
    }
}
