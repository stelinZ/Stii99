package app.sonypods

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Full 3D Sony WF-1000XM5 connection card using Three.js WebView
 * with animated battery rings drawn natively on a Canvas overlay.
 *
 * Layout stack (bottom to top):
 * 1. Rounded-rect card background (Canvas)
 * 2. WebView showing interactive 3D scene (touch-enabled)
 * 3. Title + battery rings overlay (touch pass-through)
 */
class Pods3DCardView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : FrameLayout(ctx, attrs) {

    companion object {
        const val HEIGHT_DP = 320f
    }

    var title = "WF-1000XM5"
    private var state = PodsState()
    private var shown = floatArrayOf(0f, 0f, 0f)
    private var master = 0f
    private var pulse = 0f
    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private var masterAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null
    private var shownAnim: ValueAnimator? = null
    private var sceneReady = false

    private val webView: WebView
    private val overlay: HUDOverlay

    init {
        // Card background drawn by this FrameLayout
        setWillNotDraw(false)
        clipChildren = true
        clipToOutline = true
        outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(28f))
            }
        }

        // 1) WebView — fills entire card, renders 3D
        webView = WebView(ctx).apply {
            @SuppressLint("SetJavaScriptEnabled")
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            setBackgroundColor(Color.TRANSPARENT)
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(object {
                @JavascriptInterface
                fun onSceneReady() {
                    post {
                        sceneReady = true
                        evaluateJavascript("sonyPodsApi.open()", null)
                    }
                }
            }, "Android")
            loadUrl("file:///android_asset/viewer.html")
        }
        addView(webView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        // 2) HUD overlay — title + battery rings, passes touch to WebView
        overlay = HUDOverlay(ctx)
        addView(overlay, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    // ── Card background ─────────────────────────────────────────
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat(); val r = dp(28f)
        // Deep glass card
        bgPaint.shader = LinearGradient(0f, 0f, w, h,
            intArrayOf(0xFF2A2D38.toInt(), 0xFF12141A.toInt(), 0xFF1A1C25.toInt()),
            null, Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, r, r, bgPaint)

        val glowK = ease(ph(master, .0f, .5f))
        val breathe = 0.75f + 0.25f * sin(pulse * 2f * PI.toFloat())
        bgPaint.shader = RadialGradient(w / 2, h * 0.42f, dp(200f),
            intArrayOf(
                Color.argb((50 * glowK * breathe).toInt(), 90, 150, 255),
                Color.argb((18 * glowK).toInt(), 120, 90, 255), 0x00000000
            ), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, r, r, bgPaint)

        bgPaint.shader = LinearGradient(0f, 0f, 0f, dp(80f), 0x0EFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, r, r, bgPaint); bgPaint.shader = null

        bgPaint.style = Paint.Style.STROKE; bgPaint.strokeWidth = dp(1f); bgPaint.color = 0x22FFFFFF
        c.drawRoundRect(dp(.5f), dp(.5f), w - dp(.5f), h - dp(.5f), r, r, bgPaint)
        bgPaint.style = Paint.Style.FILL
    }

    // ── Lifecycle ───────────────────────────────────────────────
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        masterAnim?.cancel()
        masterAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2300L; interpolator = LinearInterpolator()
            addUpdateListener { master = it.animatedValue as Float; invalidate(); overlay.invalidate() }
            start()
        }
        pulseAnim?.cancel()
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2600L; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { pulse = it.animatedValue as Float; invalidate(); overlay.invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        masterAnim?.cancel(); pulseAnim?.cancel(); shownAnim?.cancel()
        webView.destroy()
        super.onDetachedFromWindow()
    }

    fun setState(s: PodsState) {
        state = s
        val next = floatArrayOf(
            (s.left ?: 0).coerceIn(0, 100) / 100f,
            (s.right ?: 0).coerceIn(0, 100) / 100f,
            (s.case ?: 0).coerceIn(0, 100) / 100f
        )
        val start = shown.copyOf()
        val firstTime = master < 0.55f
        shownAnim?.cancel()
        shownAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900L; startDelay = if (firstTime) 1000L else 80L
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { a ->
                val k = a.animatedValue as Float
                for (i in 0..2) shown[i] = lerp(start[i], next[i], k)
                overlay.invalidate()
            }
            start()
        }
        overlay.invalidate()
    }

    // ── 3D API ──────────────────────────────────────────────────
    fun triggerOpen()    { if (sceneReady) webView.evaluateJavascript("sonyPodsApi.open()", null) }
    fun triggerExtract() { if (sceneReady) webView.evaluateJavascript("sonyPodsApi.extract()", null) }
    fun triggerClose()   { if (sceneReady) webView.evaluateJavascript("sonyPodsApi.close()", null) }
    fun triggerReturn()  { if (sceneReady) webView.evaluateJavascript("sonyPodsApi.returnBuds()", null) }
    fun trigger360()     { if (sceneReady) webView.evaluateJavascript("sonyPodsApi.rotate360()", null) }
    fun setColorVariant(v: String) { if (sceneReady) webView.evaluateJavascript("sonyPodsApi.setColor('$v')", null) }
    fun resetCamera()    { if (sceneReady) webView.evaluateJavascript("sonyPodsApi.resetCamera()", null) }

    // ── Measure ─────────────────────────────────────────────────
    override fun onMeasure(w: Int, h: Int) {
        val mW = MeasureSpec.getSize(w)
        val mH = dp(HEIGHT_DP).toInt()
        setMeasuredDimension(mW, mH)
        val exact = { s: Int -> MeasureSpec.makeMeasureSpec(s, MeasureSpec.EXACTLY) }
        webView.measure(exact(mW), exact(mH))
        overlay.measure(exact(mW), exact(mH))
    }

    // ── Helpers ─────────────────────────────────────────────────
    private fun lerp(a: Float, b: Float, k: Float) = a + (b - a) * k
    private fun ph(t: Float, a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)
    private fun ease(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)

    // ═══════════════════════════════════════════════════════════
    //  HUD Overlay — only draws title + battery rings
    //  Passes all touch events through to the WebView below
    // ═══════════════════════════════════════════════════════════
    inner class HUDOverlay(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
        private val rect = RectF()
        private val bolt = Path()

        init { setWillNotDraw(false) }

        // Let all touches fall through to the WebView
        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent?) = false

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()

            // ── Title ──
            val tk = ease(ph(master, .30f, .60f))
            txt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            txt.textSize = dp(18f); txt.color = Color.WHITE; txt.alpha = (255 * tk).toInt()
            c.drawText(title, w / 2, dp(30f) - dp(6f) * (1f - tk), txt)

            txt.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            txt.textSize = dp(11.5f); txt.color = 0xFFB7BBC7.toInt(); txt.alpha = (255 * tk).toInt()
            c.drawText("Подключено", w / 2, dp(47f) - dp(6f) * (1f - tk), txt)

            // ── Battery rings ──
            val ringY = h - dp(50f)
            val xs = floatArrayOf(w * .20f, w * .50f, w * .80f)
            val labels = arrayOf("ЛЕВЫЙ", "ПРАВЫЙ", "КЕЙС")
            val values = arrayOf(state.left, state.right, state.case)
            val chg = booleanArrayOf(state.leftChg, state.rightChg, state.caseChg)
            for (i in 0..2) {
                val k = ease(ph(master, .52f + i * .06f, .92f + i * .04f))
                drawRing(c, xs[i], ringY, labels[i], values[i], shown[i], chg[i], k)
            }
        }

        private fun drawRing(
            c: Canvas, cx: Float, cy: Float, label: String,
            value: Int?, frac: Float, charging: Boolean, k: Float
        ) {
            val rad = dp(18f); val sw = dp(3.5f)
            rect.set(cx - rad, cy - rad, cx + rad, cy + rad)
            p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.shader = null
            p.color = 0xFFFFFFFF.toInt(); p.alpha = (0x26 * k).toInt()
            c.drawArc(rect, 0f, 360f, false, p)
            if (value != null) {
                val col = if (charging || value > 25) 0xFF57D68D.toInt()
                else if (value > 12) 0xFFFFC45C.toInt() else 0xFFFF6B70.toInt()
                p.color = col; p.alpha = (255 * k).toInt()
                p.strokeCap = Paint.Cap.ROUND
                c.drawArc(rect, -90f, 360f * frac.coerceIn(0f, 1f) * k, false, p)
                p.strokeCap = Paint.Cap.BUTT
            }
            txt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            txt.textSize = dp(11f); txt.color = Color.WHITE; txt.alpha = (255 * k).toInt()
            c.drawText(
                if (value != null) "${(frac * 100f).roundToInt().coerceIn(0, 100)}" else "—",
                cx, cy + dp(4f), txt
            )
            txt.textSize = dp(9f); txt.color = 0xFF9299A8.toInt(); txt.alpha = (255 * k).toInt()
            c.drawText(label, cx, cy + rad + dp(16f), txt)
            if (charging && value != null) {
                val bx = cx + rad * .72f; val by = cy - rad * .72f
                bolt.reset()
                bolt.moveTo(bx + dp(1.5f), by - dp(5f))
                bolt.lineTo(bx - dp(2.5f), by + dp(.5f))
                bolt.lineTo(bx, by + dp(.5f))
                bolt.lineTo(bx - dp(1.5f), by + dp(5f))
                bolt.lineTo(bx + dp(2.5f), by - dp(.5f))
                bolt.lineTo(bx, by - dp(.5f))
                bolt.close()
                p.style = Paint.Style.FILL; p.color = 0xFF57D68D.toInt()
                p.alpha = (255 * k).toInt(); p.shader = null
                c.drawPath(bolt, p)
            }
        }
    }
}
