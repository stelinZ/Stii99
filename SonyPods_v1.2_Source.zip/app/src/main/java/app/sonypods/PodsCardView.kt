package app.sonypods

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.roundToInt
import kotlin.math.sin

data class PodsState(
    val left: Int? = null, val right: Int? = null, val case: Int? = null,
    val leftChg: Boolean = false, val rightChg: Boolean = false, val caseChg: Boolean = false
)

/**
 * AirPods-style connection card (all drawn locally, no network, no 3D engine):
 * lid flips open -> earbuds spring out of the case -> battery rings sweep and count up.
 */
class PodsCardView(ctx: Context) : View(ctx) {
    companion object { const val HEIGHT_DP = 268f }

    var title = "WF-1000XM5"
    private var state = PodsState()
    private var shown = floatArrayOf(0f, 0f, 0f)
    private var master = 0f
    private var pulse = 0f
    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rect = RectF()
    private val bolt = Path()
    private var masterAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null
    private var shownAnim: ValueAnimator? = null

    // ---- animation helpers -------------------------------------------------
    private fun ph(t: Float, a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)
    private fun ease(x: Float) = 1f - (1f - x) * (1f - x) * (1f - x)
    private fun lerp(a: Float, b: Float, k: Float) = a + (b - a) * k
    /** Damped spring: overshoots ~15% and settles, like the iOS pop-out. */
    private fun spring(x: Float): Float =
        if (x <= 0f) 0f else if (x >= 1f) 1f else 1f - exp(-6.5f * x) * cos(11f * x)

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        masterAnim?.cancel()
        masterAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2300L; interpolator = LinearInterpolator()
            addUpdateListener { master = it.animatedValue as Float; invalidate() }
            start()
        }
        pulseAnim?.cancel()
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2600L; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        masterAnim?.cancel(); pulseAnim?.cancel(); shownAnim?.cancel()
        super.onDetachedFromWindow()
    }

    fun setState(s: PodsState) {
        state = s
        val next = floatArrayOf((s.left ?: 0).coerceIn(0, 100) / 100f,
            (s.right ?: 0).coerceIn(0, 100) / 100f, (s.case ?: 0).coerceIn(0, 100) / 100f)
        val start = shown.copyOf()
        val firstTime = master < 0.55f
        shownAnim?.cancel()
        shownAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900L; startDelay = if (firstTime) 1000L else 80L
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { a ->
                val k = a.animatedValue as Float
                for (i in 0..2) shown[i] = lerp(start[i], next[i], k)
                invalidate()
            }
            start()
        }
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), dp(HEIGHT_DP).toInt())
    }

    // ---- paint helpers -----------------------------------------------------
    private fun fill(color: Int, a: Float = 1f) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = color
        p.alpha = (Color.alpha(color) * a).roundToInt().coerceIn(0, 255)
    }
    private fun stroke(color: Int, width: Float, a: Float = 1f) {
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = width; p.color = color
        p.alpha = (Color.alpha(color) * a).roundToInt().coerceIn(0, 255)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        val r = dp(32f)
        val cx = w / 2f
        val cy = dp(132f)

        val uiK = ease(ph(master, .52f, .92f))
        val lid = ease(ph(master, .04f, .32f))
        val glowK = ease(ph(master, .0f, .5f))

        // Card: deep graphite glass.
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h,
            intArrayOf(0xFF2A2D38.toInt(), 0xFF12141A.toInt(), 0xFF1A1C25.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        // Soft light pool behind the case that breathes slowly.
        val breathe = 0.75f + 0.25f * sin(pulse * 2f * PI.toFloat())
        p.shader = RadialGradient(cx, cy, dp(190f),
            intArrayOf(Color.argb((70 * glowK * breathe).toInt(), 90, 150, 255), Color.argb((26 * glowK).toInt(), 120, 90, 255), 0x00000000),
            floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        // Top highlight + hairline border.
        p.shader = LinearGradient(0f, 0f, 0f, dp(90f), 0x1AFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, w, h, r, r, p); p.shader = null
        stroke(0x33FFFFFF, dp(1f))
        c.drawRoundRect(dp(.5f), dp(.5f), w - dp(.5f), h - dp(.5f), r, r, p)

        // Title.
        val tk = ease(ph(master, .30f, .60f))
        text.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        text.textSize = dp(19f); text.color = Color.WHITE; text.alpha = (255 * tk).toInt()
        c.drawText(title, cx, dp(36f) - dp(6f) * (1f - tk), text)
        text.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        text.textSize = dp(12f); text.color = 0xFFB7BBC7.toInt(); text.alpha = (255 * tk).toInt()
        c.drawText("Подключено", cx, dp(55f) - dp(6f) * (1f - tk), text)

        // Case ground shadow.
        p.shader = RadialGradient(cx, cy + dp(40f), dp(70f), 0x66000000, 0x00000000, Shader.TileMode.CLAMP)
        rect.set(cx - dp(76f), cy + dp(28f), cx + dp(76f), cy + dp(54f)); c.drawOval(rect, p); p.shader = null

        drawLid(c, cx, cy, lid)
        drawCase(c, cx, cy)

        // Buds spring out, clipped so they emerge from the case opening.
        c.save(); c.clipRect(0f, 0f, w, cy + dp(3f))
        val kL = spring(ph(master, .30f, .80f)); val kR = spring(ph(master, .37f, .87f))
        drawBudAt(c, cx, cy, kL, false)
        drawBudAt(c, cx, cy, kR, true)
        c.restore()

        // Case front lip over the buds for depth.
        stroke(0x55FFFFFF, dp(1f)); c.drawLine(cx - dp(40f), cy + dp(3.5f), cx + dp(40f), cy + dp(3.5f), p)

        // Battery rings.
        val xs = floatArrayOf(w * .20f, w * .50f, w * .80f)
        val labels = arrayOf("ЛЕВЫЙ", "ПРАВЫЙ", "КЕЙС")
        val values = arrayOf(state.left, state.right, state.case)
        val chg = booleanArrayOf(state.leftChg, state.rightChg, state.caseChg)
        for (i in 0..2) {
            val k = ease(ph(master, .52f + i * .06f, .92f + i * .04f))
            drawRing(c, xs[i], dp(214f), labels[i], values[i], shown[i], chg[i], k)
        }
    }

    private fun drawLid(c: Canvas, cx: Float, cy: Float, k: Float) {
        // Hinged at the back edge; foreshortened as it swings up so it reads as 3D.
        val a = k * 80f * (PI.toFloat() / 180f)
        val lidH = dp(30f) * cos(a) + dp(7f) * sin(a)
        val hingeY = cy - dp(6f)
        rect.set(cx - dp(47f), hingeY - lidH, cx + dp(47f), hingeY)
        p.shader = LinearGradient(0f, hingeY - lidH, 0f, hingeY,
            intArrayOf(0xFF8A92A3.toInt(), 0xFF3A404C.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, dp(16f), dp(16f), p); p.shader = null
        stroke(0x66FFFFFF, dp(1f)); c.drawRoundRect(rect, dp(16f), dp(16f), p)
    }

    private fun drawCase(c: Canvas, cx: Float, cy: Float) {
        rect.set(cx - dp(49f), cy - dp(6f), cx + dp(49f), cy + dp(36f))
        p.shader = LinearGradient(cx - dp(49f), cy - dp(6f), cx + dp(49f), cy + dp(36f),
            intArrayOf(0xFF6A7180.toInt(), 0xFF2C313B.toInt(), 0xFF14171D.toInt()), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, dp(20f), dp(20f), p); p.shader = null
        stroke(0x66FFFFFF, dp(1f)); c.drawRoundRect(rect, dp(20f), dp(20f), p)
        // Opening slot.
        rect.set(cx - dp(42f), cy - dp(2f), cx + dp(42f), cy + dp(6f))
        fill(0xFF07080B.toInt()); c.drawRoundRect(rect, dp(4f), dp(4f), p)
        // Status LED, pulses green while the case is charging.
        val led = if (state.caseChg) 0xFF57D68D.toInt() else 0xFFB8BECB.toInt()
        val ledA = if (state.caseChg) 0.55f + 0.45f * sin(pulse * 2f * PI.toFloat()) else 0.7f
        fill(led, ledA); c.drawCircle(cx, cy + dp(27f), dp(2.4f), p)
    }

    private fun drawBudAt(c: Canvas, cx: Float, cy: Float, k: Float, right: Boolean) {
        val sgn = if (right) 1f else -1f
        val x = lerp(cx + sgn * dp(14f), cx + sgn * dp(66f), k)
        val y = lerp(cy + dp(14f), cy - dp(16f), k)
        c.save()
        c.translate(x, y)
        c.rotate(sgn * 20f * k)
        val s = lerp(.78f, 1f, k.coerceIn(0f, 1.2f)); c.scale(s, s)
        drawBud(c, right)
        c.restore()
    }

    private fun drawBud(c: Canvas, mirror: Boolean) {
        c.save(); if (mirror) c.scale(-1f, 1f)
        // Soft drop shadow.
        p.shader = RadialGradient(0f, dp(6f), dp(26f), 0x55000000, 0x00000000, Shader.TileMode.CLAMP)
        rect.set(-dp(26f), -dp(14f), dp(26f), dp(30f)); c.drawOval(rect, p)
        // Stem.
        fill(0xFF15171C.toInt()); c.drawRoundRect(-dp(5f), dp(8f), dp(6f), dp(36f), dp(5.5f), dp(5.5f), p)
        // Main shell.
        p.shader = LinearGradient(-dp(16f), -dp(26f), dp(16f), dp(20f),
            intArrayOf(0xFF9097A3.toInt(), 0xFF343842.toInt(), 0xFF111318.toInt()), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
        rect.set(-dp(16f), -dp(26f), dp(16f), dp(20f)); c.drawOval(rect, p)
        // Specular highlight.
        p.shader = RadialGradient(-dp(6f), -dp(15f), dp(15f), 0x77FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawOval(rect, p); p.shader = null
        // Copper ring + inner sensor dot.
        stroke(0xFFC9A98A.toInt(), dp(2.2f), .9f); c.drawCircle(0f, -dp(8f), dp(8.5f), p)
        fill(0xFF0A0B0E.toInt()); c.drawCircle(0f, -dp(8f), dp(4.2f), p)
        stroke(0x44FFFFFF, dp(1f)); rect.set(-dp(15.5f), -dp(25.5f), dp(15.5f), dp(19.5f)); c.drawOval(rect, p)
        c.restore()
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, label: String, value: Int?, frac: Float, charging: Boolean, k: Float) {
        val rad = dp(19f); val sw = dp(4f)
        rect.set(cx - rad, cy - rad, cx + rad, cy + rad)
        stroke(0x26FFFFFF, sw, k); c.drawArc(rect, 0f, 360f, false, p)
        if (value != null) {
            val col = if (charging || value > 25) 0xFF57D68D.toInt() else if (value > 12) 0xFFFFC45C.toInt() else 0xFFFF6B70.toInt()
            stroke(col, sw, k); p.strokeCap = Paint.Cap.ROUND
            c.drawArc(rect, -90f, 360f * frac.coerceIn(0f, 1f) * k, false, p)
            p.strokeCap = Paint.Cap.BUTT
        }
        text.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        text.textSize = dp(11.5f); text.color = Color.WHITE; text.alpha = (255 * k).toInt()
        c.drawText(if (value != null) "${(frac * 100f).roundToInt().coerceIn(0, 100)}" else "—", cx, cy + dp(4f), text)
        text.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        text.textSize = dp(9.5f); text.color = 0xFF9299A8.toInt(); text.alpha = (255 * k).toInt()
        c.drawText(label, cx, cy + rad + dp(17f), text)
        if (charging && value != null) {
            val bx = cx + rad * .72f; val by = cy - rad * .72f
            bolt.reset()
            bolt.moveTo(bx + dp(1.5f), by - dp(5f)); bolt.lineTo(bx - dp(2.5f), by + dp(.5f)); bolt.lineTo(bx, by + dp(.5f))
            bolt.lineTo(bx - dp(1.5f), by + dp(5f)); bolt.lineTo(bx + dp(2.5f), by - dp(.5f)); bolt.lineTo(bx, by - dp(.5f)); bolt.close()
            fill(0xFF57D68D.toInt(), k); c.drawPath(bolt, p)
        }
    }
}
