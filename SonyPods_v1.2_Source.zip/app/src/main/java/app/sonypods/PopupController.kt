package app.sonypods

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max

class PopupController(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val density = ctx.resources.displayMetrics.density
    private var view: PodsCardView? = null
    private var inAnim: ValueAnimator? = null
    private val hide = Runnable { dismiss() }

    private fun schedule() { h.removeCallbacks(hide); h.postDelayed(hide, 7000) }
    private fun spring(x: Float) = if (x >= 1f) 1f else 1f - exp(-6f * x) * cos(10f * x)

    fun show(title: String, s: PodsState) {
        h.post {
            if (!Settings.canDrawOverlays(ctx)) return@post
            view?.let { it.setState(s); schedule(); return@post }
            val v = PodsCardView(ctx).apply { this.title = title; setState(s) }
            val lp = WindowManager.LayoutParams(
                (ctx.resources.displayMetrics.widthPixels * 0.93f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.y = (28 * density).toInt()
            v.setOnTouchListener(object : View.OnTouchListener {
                var y0 = 0f
                var vt: VelocityTracker? = null
                override fun onTouch(x: View, e: MotionEvent): Boolean {
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            y0 = e.rawY; h.removeCallbacks(hide)
                            inAnim?.cancel()
                            vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
                        }
                        MotionEvent.ACTION_MOVE -> {
                            vt?.addMovement(e)
                            val dy = e.rawY - y0
                            // Rubber band when pulled up, 1:1 when pulled down.
                            x.translationY = if (dy < 0f) dy * 0.15f else dy
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            vt?.computeCurrentVelocity(1000)
                            val vy = vt?.yVelocity ?: 0f
                            vt?.recycle(); vt = null
                            val tap = abs(e.rawY - y0) < 8 * density
                            if (e.actionMasked == MotionEvent.ACTION_UP &&
                                (tap || x.translationY > 70 * density || vy > 1200f)) dismiss()
                            else { x.animate().translationY(0f).setDuration(260)
                                .setInterpolator(DecelerateInterpolator(2f)).start(); schedule() }
                        }
                    }
                    return true
                }
            })
            try { wm.addView(v, lp) } catch (e: Throwable) { return@post }
            view = v
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            val dist = 300 * density
            v.translationY = dist; v.alpha = 0f; v.scaleX = .94f; v.scaleY = .94f
            inAnim?.cancel()
            inAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 780L
                addUpdateListener {
                    val t = it.animatedValue as Float
                    val k = spring(t)
                    v.translationY = dist * (1f - k)
                    v.alpha = (t * 5f).coerceIn(0f, 1f)
                    val sc = .94f + .06f * k
                    v.scaleX = sc; v.scaleY = sc
                }
                start()
            }
            schedule()
        }
    }

    fun dismiss() {
        h.post {
            val v = view ?: return@post
            view = null
            h.removeCallbacks(hide); inAnim?.cancel()
            v.animate().translationY(v.translationY + 300 * density).alpha(0f).setDuration(260)
                .setInterpolator(AccelerateInterpolator(1.4f)).withEndAction {
                    try { wm.removeView(v) } catch (e: Throwable) { }
                }.start()
        }
    }
}
