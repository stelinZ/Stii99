package app.sonypods

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.BluetoothDevice
import android.content.*
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import java.util.concurrent.Executors

fun matches(ctx: Context, d: BluetoothDevice): Boolean {
    val saved = ctx.getSharedPreferences("sonypods", Context.MODE_PRIVATE).getString("addr", null)
    if (saved != null) return d.address == saved
    return try { @SuppressLint("MissingPermission") val n = d.name; n != null && n.contains("1000XM5", true) } catch (e: Throwable) { false }
}

class PodsService : Service() {
    private lateinit var popup: PopupController
    private val io = Executors.newSingleThreadExecutor()
    private var lastShow = 0L

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val d: BluetoothDevice = (if (Build.VERSION.SDK_INT >= 33)
                i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)) ?: return
            if (!matches(this@PodsService, d)) return
            when (i.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> onConnected(d)
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> popup.dismiss()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        popup = PopupController(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pods", "Слежение за наушниками", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "pods")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Sony Pods работает").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(1, n)
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED); addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_EXPORTED) else registerReceiver(rx, f)
    }

    @SuppressLint("MissingPermission")
    private fun onConnected(d: BluetoothDevice) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastShow < 8000) return
        lastShow = now
        val title = try { d.name } catch (e: Throwable) { null } ?: "WF-1000XM5"
        val cached = load()
        val a = androidBattery(d)
        popup.show(title, if (a != null) PodsState(a, a, cached.case) else cached)
        io.execute {
            var res: PodsState? = null
            repeat(3) { if (res == null) { Thread.sleep(1200); res = SonyReader.read(d) } }
            res?.let { save(it); popup.show(title, it) }
        }
    }

    private fun androidBattery(d: BluetoothDevice): Int? = try {
        (d.javaClass.getMethod("getBatteryLevel").invoke(d) as Int).takeIf { it in 0..100 }
    } catch (e: Throwable) { null }

    private fun save(s: PodsState) = getSharedPreferences("sonypods", MODE_PRIVATE).edit()
        .putInt("l", s.left ?: -1).putInt("r", s.right ?: -1).putInt("c", s.case ?: -1).apply()

    private fun load(): PodsState {
        val p = getSharedPreferences("sonypods", MODE_PRIVATE)
        fun g(k: String) = p.getInt(k, -1).takeIf { it >= 0 }
        return PodsState(g("l"), g("r"), g("c"))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { try { unregisterReceiver(rx) } catch (e: Throwable) { }; super.onDestroy() }
}
