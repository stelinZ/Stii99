package app.sonypods

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.UUID

/**
 * ЭКСПЕРИМЕНТАЛЬНО: читает заряд L / R / кейс по фирменному протоколу Sony (RFCOMM),
 * так же как делает Sony Sound Connect. Формат кадров и команд восстановлен по открытым
 * проектам (SonyHeadphonesClient, Gadgetbridge) и не проверен на реальных WF-1000XM5.
 * Если ответа нет — вернёт null, и попап покажет общий заряд из Android.
 */
object SonyReader {
    private val UUIDS = listOf("956C7B26-D49A-4BA8-B03F-B17D393CB6E2", "96CC203E-5068-46AD-B32D-E316F5E069BA")
        .map { UUID.fromString(it) }

    @SuppressLint("MissingPermission")
    fun read(d: BluetoothDevice): PodsState? {
        for (u in UUIDS) {
            var s: BluetoothSocket? = null
            try {
                s = d.createRfcommSocketToServiceRecord(u)
                s.connect()
                val r = Session(s).run()
                if (r != null) return r
            } catch (e: Throwable) {
            } finally {
                try { s?.close() } catch (e: Throwable) { }
            }
        }
        return null
    }

    private class Session(val s: BluetoothSocket) {
        val inp = s.inputStream
        val out = s.outputStream
        val buf = ByteArrayOutputStream()
        var seq = 0
        var l: Int? = null; var r: Int? = null; var cs: Int? = null; var single: Int? = null
        var lc = false; var rc = false; var cc = false

        fun run(): PodsState? {
            send(0x0C, byteArrayOf(0x00, 0x00)); pump(900)
            for (t in intArrayOf(0x09, 0x0A, 0x00)) { send(0x0C, byteArrayOf(0x22, t.toByte())); pump(700) }
            pump(1500)
            if (l == null && cs == null && single == null) return null
            return PodsState(l ?: single, r ?: single, cs, lc, rc, cc)
        }

        fun send(type: Int, payload: ByteArray, seqNo: Int = seq) {
            out.write(frame(type, seqNo, payload)); out.flush()
            if (type != 0x01) seq = seq xor 1
        }

        fun frame(type: Int, sq: Int, payload: ByteArray): ByteArray {
            val body = ByteArrayOutputStream()
            body.write(type); body.write(sq)
            body.write(ByteBuffer.allocate(4).putInt(payload.size).array()); body.write(payload)
            val b = body.toByteArray()
            var sum = 0; for (x in b) sum += x.toInt() and 0xFF
            val full = b + (sum and 0xFF).toByte()
            val res = ByteArrayOutputStream(); res.write(0x3E)
            for (x in full) {
                val v = x.toInt() and 0xFF
                if (v == 0x3D || v == 0x3E || v == 0x3C) { res.write(0x3D); res.write(v and 0xEF) } else res.write(v)
            }
            res.write(0x3C)
            return res.toByteArray()
        }

        fun pump(ms: Long) {
            val end = SystemClock.elapsedRealtime() + ms
            while (SystemClock.elapsedRealtime() < end) {
                val n = inp.available()
                if (n > 0) { val tmp = ByteArray(n); val got = inp.read(tmp); buf.write(tmp, 0, got); drain() }
                else Thread.sleep(40)
                if (l != null && cs != null) break
            }
        }

        fun drain() {
            val a = buf.toByteArray(); var start = -1; var used = 0
            for (i in a.indices) {
                val b = a[i].toInt() and 0xFF
                if (b == 0x3E) start = i
                else if (b == 0x3C && start >= 0) { handle(unescape(a, start + 1, i)); used = i + 1; start = -1 }
            }
            buf.reset(); if (used < a.size) buf.write(a, used, a.size - used)
        }

        fun unescape(a: ByteArray, from: Int, to: Int): ByteArray {
            val o = ByteArrayOutputStream(); var esc = false
            for (i in from until to) {
                val v = a[i].toInt() and 0xFF
                if (esc) { o.write(v or 0x10); esc = false } else if (v == 0x3D) esc = true else o.write(v)
            }
            return o.toByteArray()
        }

        fun handle(f: ByteArray) {
            if (f.size < 7) return
            val type = f[0].toInt() and 0xFF; val sq = f[1].toInt() and 0xFF
            val len = ByteBuffer.wrap(f, 2, 4).int
            if (len < 0 || 6 + len > f.size) return
            if (type == 0x0C || type == 0x0E) {
                send(0x01, ByteArray(0), (sq xor 1) and 1)
                parse(f.copyOfRange(6, 6 + len))
            }
        }

        fun parse(p: ByteArray) {
            if (p.size < 3) return
            fun u(i: Int) = p[i].toInt() and 0xFF
            if (u(0) != 0x23 && u(0) != 0x25) return
            when (u(1)) {
                0x09 -> if (p.size >= 6) { l = u(2); lc = u(3) == 1; r = u(4); rc = u(5) == 1 }
                0x0A -> { cs = u(2); cc = p.size > 3 && u(3) == 1 }
                0x00 -> single = u(2)
            }
        }
    }
}
